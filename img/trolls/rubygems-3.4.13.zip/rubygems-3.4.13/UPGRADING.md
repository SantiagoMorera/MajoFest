# How to upgrade/downgrade Rubygems:

## Downgrade Recipe

    $ gem update --system 3.1.4

## Upgrade Recipe

    $ gem update --system

## Install from source

*   Download from: https://rubygems.org/pages/download
*   Unpack into a directory and `cd` there
*   Install with: `ruby setup.rb`
